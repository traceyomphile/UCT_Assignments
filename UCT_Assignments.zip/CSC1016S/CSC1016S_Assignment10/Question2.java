import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.Stack;

public class Question2 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Stack<Character> matched = new Stack<>();
        Stack<Character> excessOpeningCharacters = new Stack<>();
        Stack<Character> excessClosingCharacters = new Stack<>();

        System.out.println("Enter a string to test:");
        String string = scanner.nextLine();

        Stack<Character> brackets = new Stack<>();
        for (int i = 0; i < string.length(); i++) {

        }

        scanner.close();
        System.exit(0);
    }

    private static boolean isOpeningBracket(char bracket) {
        char[] opening = {'(', '<', '{', '['};
        for (int i = 0; i < opening.length; i++) {
            if (opening[i] == bracket) {
                return true;
            }
        } return false;
    }

    private static boolean isBalanced(String string) {
        int opening = 0;
        int closing = 0;
        for (int i = 0; i < string.length(); i++) {
            if (isOpeningBracket(string.charAt(i))) {
                opening++;
            } else {
                closing++;
            }
        }
        return (opening == closing);
    }

    private static Stack<Character> asList(String string) {
        Stack<Character> brackets = new Stack<>();
        for (int i = 0; i < string.length(); i++) {
            brackets.add(string.charAt(i));
        } return brackets;
    }

    private static char getCorresponding(char c) {
        char[] closing = {')', '>', '}', ']'};
        char[] opening = {'(', '<', '{', '['};

        for (int i = 0; i < opening.length; i++) {
            if (isOpeningBracket(c)) {
                if (opening[i] == c) {
                    return closing[i];
                }
            } else {
                if (closing[i] == c) {
                    return opening[i];
                }
            }
        } throw new NoSuchElementException();
    }


}
