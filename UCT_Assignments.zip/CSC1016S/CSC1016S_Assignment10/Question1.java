import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Question1 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Queue<String> buffer = new LinkedList<>();

        String string;
        string = scanner.nextLine();
        while ((string.charAt(0) != 'X') && (string.charAt(0) != 'x')) {
            if ((string.charAt(0) == 'O') || (string.charAt(0) == 'o')) {
                if (buffer.isEmpty()) {
                    System.out.println("Buffer empty");
                } else {
                    System.out.println("Data: " + buffer.remove());
                }
            } else {
                buffer.offer(string);
            } string = scanner.nextLine();
        }
        scanner.close();
        System.exit(0);
    }
}
