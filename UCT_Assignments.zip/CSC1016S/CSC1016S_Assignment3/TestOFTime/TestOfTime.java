import static org.junit.Assert.*;
import org.junit.Test;

public class TestOfTime {
    
    @Test
    public void testOne() {
        Time t1 = new Time("14:05");
        assertEquals("14:05:00", t1.toString());
    }

    @Test 
    public void testTwo() {
        Time timeA = new Time("09:23");
        Time timeB = new Time("15:34");
        Duration difference = timeB.subtract(timeA);
        assertEquals(new Duration(22260000), new Duration(difference));
    }

    @Test
    public void testThree() {
        Time time = new Time("10:00");
        assertEquals(new Duration(0), time.subtract(time));
    }

    @Test
    public void testFour() {
        Duration duration = new Duration("minute", 371);
        assertEquals(22260000, duration.intValue("millisecond"));
    }

    @Test
    public void testFive() {
        Duration duration = new Duration("minute", 371);
        assertEquals(22260, duration.intValue("seconds"));
    }

    @Test
    public void testSix() {
        Duration duration = new Duration("minute", 371);
        assertEquals(371, duration.intValue("minute"));
    }

    @Test
    public void testSeven() {
        Duration duration = new Duration("minute", 371);
        assertEquals(6, duration.intValue("hour"));
    }
}
