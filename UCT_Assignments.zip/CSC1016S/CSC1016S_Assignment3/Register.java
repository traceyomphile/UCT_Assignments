import java.util.*;

public class Register {
    Ticket[] tickets;
    int numTickets;

    public Register() {
        this.tickets = new Ticket[100];
        this.numTickets = 0;
    }

    public void add(Ticket ticket) {
        if (numTickets != tickets.length) {
            tickets[numTickets] = ticket;
            numTickets += 1;
        } else {
            Ticket[] tickets2 = new Ticket[numTickets+1];
            System.arraycopy(tickets, 0, tickets2, 0, tickets.length);
            tickets2[numTickets] = ticket;
            this.tickets = tickets2;
            numTickets += 1;
        }
    }

    public boolean contains(String ticketID) {
        for (int i = 0; i < numTickets; i++) {
            if (tickets[i].ID().equals(ticketID)) {
                return true;
            }
        } return false;
    }

    public Ticket retrieve(String ticketID) {
        for (int i = 0; i < numTickets; i++) {
            if (tickets[i].ID().equals(ticketID)) {
                return tickets[i];
            }
        } throw new NoSuchElementException("Ticket not found!");
    }
}
