public class Ticket {
    private String id;
    Time issueTime;

    public Ticket(Time currentTime, String ID) {
        this.id = ID;
        this.issueTime = new Time(currentTime.toString());
    }

    public String ID() {
        return this.id;
    }

    public Duration age(Time currenTime) {
        return currenTime.subtract(this.issueTime);
    }

    public String toString() {
        String string = "Ticket[id=" +  this.id + ", time=" + this.issueTime.toString() + "].";
        return string;
    }
}
