import java.util.Scanner;
/**
 * Write a description of class CarParkSimSolution here.
 *
 * @author Tracey Letlape
 * @version II
 */
public class CarParkSim {
    private static final Currency currency = new Currency("R", "ZAR", 100);
    
    private CarParkSim() {}

    private static TariffTable createTariffTable() {
        TariffTable tariffTable = new TariffTable(10);
        tariffTable.addTariff(new TimePeriod(new Duration("minute", 0), new Duration("minute", 30)), new Money("R10.00", currency));
        tariffTable.addTariff(new TimePeriod(new Duration("minute", 30), new Duration("hour", 1)), new Money("R15.00", currency));
        tariffTable.addTariff(new TimePeriod(new Duration("hour", 1), new Duration("hour", 3)), new Money("R20.00", currency));
        tariffTable.addTariff(new TimePeriod(new Duration("hour", 3), new Duration("hour", 4)), new Money("R30.00", currency));
        tariffTable.addTariff(new TimePeriod(new Duration("hour", 4), new Duration("hour", 5)), new Money("R40.00", currency));
        tariffTable.addTariff(new TimePeriod(new Duration("hour",5), new Duration("hour", 6)), new Money("R50.00", currency));
        tariffTable.addTariff(new TimePeriod(new Duration("hour", 6), new Duration("hour", 8)), new Money("R60.00", currency));
        tariffTable.addTariff(new TimePeriod(new Duration("hour", 8), new Duration("hour", 10)), new Money("R70.00", currency));
        tariffTable.addTariff(new TimePeriod(new Duration("hour", 10), new Duration("hour", 12)), new Money("R90.00", currency));
        tariffTable.addTariff(new TimePeriod(new Duration("hour", 12), new Duration("day", 1)), new Money("R100.00", currency));
        return tariffTable;
    }


    public static void main(final String[] args) {
        final Scanner keyboard = new Scanner(System.in);
        final Clock clock = new Clock(new Time("00:00:00"));
        final Register register = new Register();
        final TariffTable tariffTable = createTariffTable();
        
        System.out.println("Car Park Simulator");
        System.out.printf("The current time is %s.\n", clock.examine());
        System.out.println("Commands: tariffs, advance {minutes}, arrive, depart, quit.");
        System.out.print(">");
        String input = keyboard.next().toLowerCase();
        while (!input.equals("quit")) {
            if (input.equals("advance")) {
                clock.advance(new Duration("minute", keyboard.nextInt()));  
                System.out.printf("The current time is %s.\n", clock.examine());
            }
            else if (input.equals("arrive")) {
                final Ticket ticket = new Ticket(clock.examine(), UIDGenerator.makeUID());
                register.add(ticket);
                System.out.printf("Ticket issued: %s.\n", ticket);
            }
            else if (input.equals("depart")) {
                final String ID = keyboard.next();
                if (!register.contains(ID)) {
                    System.out.println("Invalid ticket ID.");
                }
                else {
                    final Ticket ticket = register.retrieve(ID);
                    System.out.printf("Ticket details: %s.\n", ticket);
                    System.out.printf("Current time: %s.\n", clock.examine());
                    final Duration durationOfStay = ticket.age(clock.examine());
                    System.out.printf("Duration of stay: %s.\n", Duration.format(durationOfStay, "hour", "minute"));
                    System.out.println("Cost of stay : " + tariffTable.getTariff(durationOfStay) + ".");
                }
            } 
            else if (input.equals("tariffs")) {
                System.out.println(tariffTable.toString());
            }
            else {
                System.out.println("That command is not recognised.");
                System.out.println("Commands: tariffs, advance <minutes>, arrive, depart, quit.");
            }            
            System.out.print(">");
            input = keyboard.next().toLowerCase();
        }            
        System.out.println("Goodbye.");
    }

}
