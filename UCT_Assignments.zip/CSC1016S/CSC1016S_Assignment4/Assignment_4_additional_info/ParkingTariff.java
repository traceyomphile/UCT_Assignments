public class ParkingTariff {
    private TimePeriod timePeriod;
    private Money tariff;
    private final Currency currency = new Currency("R", "ZAR", 100);

    public ParkingTariff() {
        this.timePeriod = null;
        this.tariff = new Money(0, currency);
    }

    public ParkingTariff(TimePeriod timePeriod, Money tariff) {
        this.timePeriod = timePeriod;
        this.tariff = tariff;
    }

    public ParkingTariff(ParkingTariff parkingTariff) {
        this.timePeriod = new TimePeriod(parkingTariff.getTimePeriod());
        this.tariff = new Money(parkingTariff.getTariff().toString(), currency);
    }

    public TimePeriod getTimePeriod() {
        return new TimePeriod(timePeriod);
    }

    public Money getTariff() {
        return new Money(tariff.toString(), currency);
    }

    public void setTimePeriod(TimePeriod timePeriod) {
        this.timePeriod = timePeriod;
    }

    public void setTariff(Money tariff) {
        this.tariff = tariff;
    }

    public boolean includes(Duration duration) {
        return (this.timePeriod.includes(duration));
    }
}
