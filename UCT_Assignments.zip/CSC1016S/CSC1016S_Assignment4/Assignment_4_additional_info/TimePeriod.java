public class TimePeriod {
    private Duration upperBound, lowerBound;

    public TimePeriod(Duration lowerBound, Duration upperBound) {
        this.upperBound = new Duration(upperBound);
        this.lowerBound = new Duration(lowerBound);
    }

    public TimePeriod(TimePeriod other) {
        this.upperBound = new Duration(other.upperBound());
        this.lowerBound = new Duration(other.lowerBound());
    }

    public Duration lowerBound() {
        return new Duration(lowerBound);
    }

    public Duration upperBound() {
        return new Duration(upperBound);
    }
    
    public boolean includes(Duration duration) {
        return ((this.lowerBound.intValue() <= duration.intValue()) && (duration.intValue() <= this.upperBound.intValue()));
    }

    public boolean precedes(TimePeriod other) {
        return (this.upperBound.intValue() <= other.lowerBound().intValue());
    }

    public boolean adjacent(TimePeriod other) {
        return ((this.upperBound.equals(other.lowerBound())) || (this.lowerBound.equals(other.upperBound())));
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof TimePeriod)) {
            return false;
        } else {
            TimePeriod other = (TimePeriod)object;
            return (this.lowerBound.equals(other.lowerBound()) && this.upperBound.equals(other.upperBound()));
        }
    }

    @Override
    public String toString() {
        String string  = "[" + Duration.format(this.lowerBound, "minute") +  " .. " + Duration.format(this.upperBound, "minute") + "]";
        return string;
    }
}
