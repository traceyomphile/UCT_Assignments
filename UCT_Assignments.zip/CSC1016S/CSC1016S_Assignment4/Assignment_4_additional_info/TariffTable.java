

public class TariffTable {
    private ParkingTariff[] tariffTable;
    private int numberOfParkingTariffs;

    public TariffTable(int maxSize) {
        this.numberOfParkingTariffs = 0;
        tariffTable = new ParkingTariff[maxSize];
    } 

    public void addTariff(TimePeriod period, Money tariff) {
        if (numberOfParkingTariffs == 0) {
            tariffTable[numberOfParkingTariffs] = new ParkingTariff(period, tariff);
            numberOfParkingTariffs++;
        } else {
            ParkingTariff parkingTariff = new ParkingTariff(period, tariff);
            if (tariffTable[numberOfParkingTariffs - 1].getTimePeriod().adjacent(period)) {
                tariffTable[numberOfParkingTariffs] = parkingTariff;
                numberOfParkingTariffs++;
            } else {
                throw  new IllegalArgumentException("TimePeriod:addTariff():precondition not met.");
            }
        }
    }

    public Money getTariff(Duration lengthOfStay) {
        if (this.numberOfParkingTariffs == 0) {
            System.out.println("Parking space is free. No charges applicable yet!");
            return new Money(0, new Currency("R", "ZAR", 100));
        } else {
            for (int i = 0; i < numberOfParkingTariffs; i++) {
                if (tariffTable[i].getTimePeriod().includes(lengthOfStay)) {
                    return tariffTable[i].getTariff();
                }
            } if (tariffTable[numberOfParkingTariffs-1].getTimePeriod().upperBound().compareTo(lengthOfStay) <= 0) {
                return tariffTable[numberOfParkingTariffs-1].getTariff();
            } else {
                throw new IllegalArgumentException();
            }
        }
    }

    @Override
    public String toString() {
        if (numberOfParkingTariffs == 0) {
            return "Tariff table is empty. Add tairff to set up a tariff table.";
        } else {
            String string = "";
            for (int i = 0; i < numberOfParkingTariffs; i++) {
                string = string + tariffTable[i].getTimePeriod().toString() + " : " + tariffTable[i].getTariff().toString() + "\n";
            } return string.trim();
        }
    }



}
