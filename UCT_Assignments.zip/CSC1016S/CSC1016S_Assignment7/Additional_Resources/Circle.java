public class Circle extends Shape {

    private double radius;

    public Circle(String name, String color, double radius) {
        super(name, color);
        this.radius = radius;
    }

    public double getRadius() {return this.radius;}

    public double getArea() {return Math.PI*Math.pow(this.radius, 2);}

    public double getPerimeter() {return 2*Math.PI*this.radius;}

    @Override
    public String toString() {return super.toString() + " Radius " + this.radius;}
}
