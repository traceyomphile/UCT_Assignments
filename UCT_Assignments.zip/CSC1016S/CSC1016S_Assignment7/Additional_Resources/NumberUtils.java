
public class NumberUtils {

    private NumberUtils() {}

    public static int[] toArray(int number) {
        String string = "" + number;
        int[] num = new int[string.length()];

        for (int i = 0; i < num.length; i++) {
            num[i] = Integer.parseInt(string.substring(i, i+1));
        } return num;
    }

    public static int countMatches(int numberA, int numberB) {
        int matches = 0;
        int[] NumberA = toArray(numberA);
        int[] NumberB = toArray(numberB);
        for (int i = 0; i < NumberA.length; i++) {
            if (NumberA[i] == NumberB[i]) {
                matches++;
            }
        } return matches;
    }

    public static int countIntersect(int numberA, int numberB) {
        int matches = 0;
        int[] NumberA = toArray(numberA);
        int[] NumberB = toArray(numberB);
        for (int i = 0; i < NumberA.length; i++) {
            for (int j = 0; j < NumberB.length; j++) {
                if ((i != j) && NumberA[i] == NumberB[j]) {
                    matches++;
                    break;
                }
            } 
        } return matches;
    }
    
}
