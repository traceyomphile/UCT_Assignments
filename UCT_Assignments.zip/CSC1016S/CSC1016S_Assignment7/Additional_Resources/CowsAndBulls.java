public class CowsAndBulls {
    
    private int mysteryNum;
    private int guessesRemaining;
    private Result result;

    public static final int NUM_DIGITS = 4;
    public static final int MAX_VALUE = 9876;
    public static final int MIN_VALUE = 1234;
    public static final int MAX_GUESSES = 10;

    public CowsAndBulls(int seed) {
        NumberPicker numberPicker = new NumberPicker(seed, 1, 9);
        this.mysteryNum = numberPicker.nextInt();
        while ((NumberUtils.toArray(this.mysteryNum).length != NUM_DIGITS) && this.mysteryNum < MIN_VALUE && this.mysteryNum < MAX_VALUE) {
            this.mysteryNum = (this.mysteryNum*10) + numberPicker.nextInt();
        } this.guessesRemaining = MAX_GUESSES;
    }

    public int guessesRemaining() {
        return this.guessesRemaining;
    }

    public Result guess(int guessNumber) {
        this.result = new Result(NumberUtils.countIntersect(this.mysteryNum, guessNumber), NumberUtils.countMatches(this.mysteryNum, guessNumber));
        this.guessesRemaining--;
        return this.result;
    }

    public int giveUp() {
        this.guessesRemaining = 0;
        return this.mysteryNum;
    }

    public boolean gameover() {
        return (result.isCorrect() || this.guessesRemaining == 0);
    }
}
