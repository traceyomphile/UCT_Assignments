public class Rectangle extends Shape {
    private double length, width;

    public Rectangle(String name, String color, double length, double width) {
        super(name, color);
        this.length = length;
        this.width = width;
    }

    public double getLength() {return this.length;}

    public double getWidth() {return this.width;}

    public double getArea() {return this.length*this.width;}

    public double getPerimeter() {return (2*this.length)+(2*this.width);}

    @Override
    public String toString() {return super.toString() + " Length " + this.length + " Width " + this.width;}
}
