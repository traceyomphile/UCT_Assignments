import java.util.Scanner;

public class TestSeller {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Seller seller = new Seller();
        Currency currency = new Currency("R", "ZAR", 100);

        System.out.println("Pleae enter the details of the seller.");

        System.out.print("ID: ");
        seller.ID = scanner.nextLine();

        System.out.print("Name: ");
        seller.Name = scanner.nextLine();

        System.out.print("Location: ");
        seller.Location = scanner.nextLine();

        System.out.print("Product: ");
        seller.Product = scanner.nextLine();

        System.out.print("Price: ");
        seller.unit_price = new Money(scanner.nextLine(), currency);

        System.out.print("Units: ");
        seller.number_of_units = scanner.nextInt();

        System.out.println("The seller has been successfully created:");
        System.out.println("ID of the seller: " + seller.ID);
        System.out.println("Name of the seller: " + seller.Name);
        System.out.println("Location of the seller: " + seller.Location);
        System.out.println("The product to sell: " + seller.Product);
        System.out.println("Product unit price: " + seller.unit_price.toString());
        System.out.println("The number of available units: " + seller.number_of_units);

        
    }

}
