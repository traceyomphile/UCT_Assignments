public class Seller {
    public String ID, Name, Location, Product;
    public Money unit_price;
    public int number_of_units;

    public Seller() {}

    public Seller(Seller seller) {
        this.ID = seller.ID;
        this.Name = seller.Name;
        this.Location = seller.Location;
        this.Product = seller.Product;
        this.unit_price = new Money(seller.unit_price.toString(), seller.unit_price.currency());
        this.number_of_units = seller.number_of_units;
    }

    public String toString() {
        String string = this.ID + " : " + this.Name + " in " + this.Location + " has " + this.number_of_units + " " + this.Product + " for " + this.unit_price.toString() + " each.";
        return string;
    }
    
}
