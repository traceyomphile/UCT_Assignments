
import java.util.ArrayList;
import java.util.List;

public class Employee {
    String name, UID;
    ArrayList<Shift> shifts;
    CalendarTime signIn;

    public Employee(String name, String UID) {
        this.name = name;
        this.UID = UID;
        shifts = new ArrayList<>();
    }

    public String name() {
        return this.name;
    }

    public String UID() {
        return this.UID;
    }

    public void signIn(Date d, Time t) {
        this.signIn = new CalendarTime(d, t);
    }

    public void signOut(Date d, Time t) {
        this.shifts.add(new Shift(signIn, new CalendarTime(d, t)));
    }

    public boolean present() {
        if (signIn != null) {
            for (Shift shift : shifts) {
                if (shift.start().equals(signIn)) {
                    return false;
                }
            } return true;
        } return false;
    }

    public List<Shift> get(Week w) {
        List<Shift> shiftsInWeek = new ArrayList<>();
        if (shifts.isEmpty()) {
            throw new NullPointerException();
        } else {
            for (Shift shift : shifts) {
                if (shift.inWeek(w)) {
                    shiftsInWeek.add(shift);
                }
            }
        } return shiftsInWeek;
    }

    public Duration hours(Week w) {
        Duration hoursWorked = new Duration(0);
        for (Shift shift : get(w)) {
            hoursWorked.add(shift.length());
        } return hoursWorked;
    }

}
