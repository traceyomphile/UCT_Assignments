/** Functions for manipulating vector.
 * @author Tracey Letlape
 * @Date 10/2/25
 */

public class Vector {
    private double xcompoonent, ycomponent;

    // Create a vector with the given vector xcomponent and ycomponent.
    public Vector(double xcompoonent, double ycomponent) {
        this.xcompoonent = xcompoonent;
        this.ycomponent = ycomponent;
    }

    // Create a copy of the vector.
    public Vector(Vector v) {
        this.xcompoonent = v.xcompoonent();
        this.ycomponent = v.ycomponent();
    }

    // get the xcomponent of the vector.
    public double xcompoonent() {
        return this.xcompoonent;
    }

    // get the ycomponent of the vector.
    public double ycomponent() {
        return this.ycomponent;
    }

    // get the magnitude of the vector.
    public double getMagnitude() {
        return Math.sqrt(Math.pow(xcompoonent, 2) + Math.pow(ycomponent, 2));
    }

    // returns the vector that is the sum of two vectors.
    public Vector add(Vector v) {
        return new Vector(this.xcompoonent + v.xcompoonent(), this.ycomponent + v.ycomponent());
    }

    // returns a Vector that is a scalar multiple of the this vector. 
    public Vector multiply(double m) {
        return new Vector(m*xcompoonent, m*ycomponent);
    }

    // returns the dotProduct of this vector and the given vector.
    public double dotProduct(Vector v) {
        return (this.xcompoonent*v.xcompoonent() + this.ycomponent*v.ycomponent());
    }

    @Override
    public String toString() {
        return String.format("v = (%.2f, %.2f)", this.xcompoonent, this.ycomponent);
    }

}
