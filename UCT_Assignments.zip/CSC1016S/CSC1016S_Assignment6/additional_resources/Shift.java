public class Shift {
    private CalendarTime start, finish;

    public Shift(CalendarTime start, CalendarTime finish) {
        this.start = start;
        this.finish = finish;
    }

    public Shift(Shift other) {
        this.start = new CalendarTime(other.start().date(), other.start().time());
        this.finish = new CalendarTime(other.finish().date(), other.finish().time());
    }

    public CalendarTime start() {
        return new CalendarTime(this.start.date(), this.start.time());
    }

    public CalendarTime finish() {
        return new CalendarTime(this.finish.date(), this.finish.time());
    }

    public boolean inWeek(Week w) {
        return (Week.weekOf(start.date()).equals(w) || Week.weekOf(finish.date()).equals(w));
    }

    public Duration length() {
        return this.finish.subtract(start);
    }

    @Override
    public String toString() {
        return (this.start.toString() + " - " + this.finish.toString());
    }
    
}
