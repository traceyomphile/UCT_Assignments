public class Rectangle extends VectorObject{

    private int xLen, yLen;

    public Rectangle(int id, int x, int y, int xLen, int yLen) {
        super(id, x, y);
        this.xLen = xLen;
        this.yLen = yLen;
    }

    @Override
    public void draw ( char [][] matrix ) {
        for (int i = y; i < (yLen+y); i++) {
            for (int j = x; j < (xLen+x); j++) {
                matrix[i][j] = '*';
            }
        }
    }

}
