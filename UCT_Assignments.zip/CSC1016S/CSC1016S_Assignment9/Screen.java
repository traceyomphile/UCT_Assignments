public class Screen extends Accessory {

    private int size;

    public Screen() {}

    public Screen(int serialNumber, String manufacturer, String color, int size) {
        super(serialNumber, manufacturer, color);
        this.size = size;
    }

    public Screen(Screen other) {
        super(other);
        this.size = other.getSize();
    }

    public int getSize() {return this.size;}

    public void setSize(int size) {this.size = size;}

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof  Screen)) {
            return false;
        } else {
            Screen other = (Screen)o;
            return (super.equals(other) && (this.size == other.getSize())); 
        }
    }

    @Override
    public String toString() {
        return (super.toString() + ", " + this.size);
    }

}
