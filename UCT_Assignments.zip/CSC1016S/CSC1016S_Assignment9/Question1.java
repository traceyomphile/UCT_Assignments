import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Question1 {

    private Question1() {}

    public static void main(String[] args) {
        List<Accessory> details = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to Great International Technology");
        System.out.println("MENU: add (B)ox, add (S)creen, add (A)ccessories, (D)elete, (L)ist, (Q)uit");
        String choice = scanner.nextLine();
        while(!(choice.equalsIgnoreCase("Q") || choice.equalsIgnoreCase("Quit"))) {
            if (choice.equalsIgnoreCase("B") || choice.equalsIgnoreCase("Box")) {
                Box box = new Box();
                System.out.println("Enter the serial number");
                box.setSerialNumber(scanner.nextInt());
                scanner.nextLine();
                System.out.println("Enter the manufacturer");
                box.setManufacturer(scanner.nextLine());
                System.out.println("Enter the colour");
                box.setColor(scanner.nextLine());
                System.out.println("Enter the amount of memory (MB)");
                box.setamountOfMemory(scanner.nextInt());
                scanner.nextLine();
                details.add(box);
                System.out.println("Done");
            }
            else if (choice.equalsIgnoreCase("S") || choice.equalsIgnoreCase("Screen")) {
                Screen screen = new Screen();
                System.out.println("Enter the serial number");
                screen.setSerialNumber(scanner.nextInt());
                scanner.nextLine();
                System.out.println("Enter the manufacturer");
                screen.setManufacturer(scanner.nextLine());
                System.out.println("Enter the colour");
                screen.setColor(scanner.nextLine());
                System.out.println("Enter the screen size in inches");
                screen.setSize(scanner.nextInt());
                scanner.nextLine();
                details.add(screen);
                System.out.println("Done");
            }
            else if (choice.equalsIgnoreCase("A") || choice.equalsIgnoreCase("Accessories")) {
                Accessory accessory = new Accessory();
                System.out.println("Enter the serial number");
                accessory.setSerialNumber(scanner.nextInt());
                scanner.nextLine();
                System.out.println("Enter the manufacturer");
                accessory.setManufacturer(scanner.nextLine());
                System.out.println("Enter the colour");
                accessory.setColor(scanner.nextLine());
                details.add(accessory);
                System.out.println("Done");
            }
            else if (choice.equalsIgnoreCase("D") || choice.equalsIgnoreCase("Delete")) {
                System.out.println("Enter the serial number");
                int serialNumber = scanner.nextInt();
                scanner.nextLine();
                boolean found = false;
                for (Accessory detail : details) {
                    if (detail.getSerialNumber() == serialNumber) {
                        details.remove(detail);
                        found = true;
                    }
                } if (found) {System.out.println("Done");}
                else {System.out.println("Not found");}
            }
            else if (choice.equalsIgnoreCase("L") || choice.equalsIgnoreCase("List")) {
                for (Accessory detail : details) {
                    if (detail.getClass().getName().equals("Accessory")) {
                        System.out.println("Accessories: " + detail.toString());
                    } else if (detail.getClass().getName().equals("Box")) {
                        System.out.println("Box: " + detail.toString());
                    } else {
                        System.out.println("Screen: " + detail.toString());
                    }
                } System.out.println("Done");
            }
            else {
                System.err.println("Invalid choice! Please choose again.");
            }
            System.out.println("MENU: add (B)ox, add (S)creen, add (A)ccessories, (D)elete, (L)ist, (Q)uit");
            choice = scanner.nextLine();
        }
        
        scanner.close();
        System.exit(0);
    }
}
