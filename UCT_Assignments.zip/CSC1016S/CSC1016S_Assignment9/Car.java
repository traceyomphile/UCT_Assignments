public class Car extends Vehicle {

    private int seatingCapacity;
    private double carWeight;

    public Car(int numCylinders, String maker, Student owner, int passengers, double carWeight) {
        super(numCylinders, maker, owner);
        this.seatingCapacity = passengers;
        this.carWeight = carWeight;
    }

    public Car(Car c) {
        super(c);
        this.seatingCapacity = c.getSeatingcapacity();
        this.carWeight = c.getCarWeight();
    }

    public int getSeatingcapacity() {return this.seatingCapacity;}

    public double getCarWeight() {return this.carWeight;}

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Car)) {
            return false;
        } else {
            Car other = (Car)o;
            return (
                (super.equals(other)) &&
                (this.seatingCapacity == other.getSeatingcapacity()) &&
                (this.carWeight == other.getCarWeight())
            );
        }
    }

    @Override
    public String toString() {
        return (super.toString() + " The car is a " + this.seatingCapacity + "-seater weighing " + this.carWeight + " kg");
    }

}
