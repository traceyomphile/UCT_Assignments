public class Accessory {

    private int serialNumber;
    private String manufacturer, color;
    
    public Accessory() {}

    public Accessory(int serialNumber, String manufacturer, String color) {
        this.serialNumber = serialNumber;
        this.manufacturer = manufacturer;
        this.color = color;
    }

    public Accessory(Accessory other) {
        this.serialNumber = other.getSerialNumber();
        this.manufacturer = other.getManufacturer();
        this.color = other.getColor();
    }

    public int getSerialNumber() {return this.serialNumber;}

    public String getManufacturer() {return this.manufacturer;}

    public String getColor() {return this.color;}

    public void setSerialNumber(int serialNumber) {this.serialNumber = serialNumber;}

    public void setManufacturer(String manufacturer) {this.manufacturer = manufacturer;}

    public void setColor(String color) {this.color = color;}
    
    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Accessory)) {
            return false;
        } else {
            Accessory other = (Accessory)o;
            return ((this.serialNumber == other.getSerialNumber()) && (this.manufacturer.equals(other.getManufacturer())) && this.color.equals(other.getColor()));
        }
    }

    @Override
    public String toString() {
        return (this.serialNumber + ", " + this.manufacturer + ", " + this.color);
    }
    
}
