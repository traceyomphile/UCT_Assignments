public class Vehicle {
    private int numCylinders;
    private String maker;
    private Student owner;

    public Vehicle(int numCylinders, String maker, Student owner) {
        this.numCylinders = numCylinders;
        this.maker = maker;
        this.owner = owner;
    }

    public Vehicle(Vehicle v) {
        this.numCylinders = v.getNumCylinders();
        this.maker = v.getMaker();
        this.owner = new Student(v.getOwner());
    }

    public int getNumCylinders() {return this.numCylinders;}

    public String getMaker() {return this.maker;}

    public Student getOwner() {return new Student(this.owner);}

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Vehicle)) {
            return false;
        } else {
            Vehicle other = (Vehicle)o;
            return(
                (this.numCylinders == other.getNumCylinders()) &&
                (this.maker.equalsIgnoreCase(other.getMaker())) &&
                (this.owner.equals(other.getOwner()))
            );
        }
    }

    @Override
    public String toString() {
        return (this.maker + ", " + this.numCylinders + " cylinders, owned by " + owner.toString());
    }
}
