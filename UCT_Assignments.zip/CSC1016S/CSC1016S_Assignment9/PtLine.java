public class PtLine extends VectorObject {

    private int x1, y1;

    public PtLine(int id, int x, int y, int x1, int y1) {
        super(id, x, y);
        this.x1 = x1;
        this.y1 = y1;
    }

    @Override
    public void draw ( char [][] matrix ) {
        if ((x < x1) && (y < y1)) {
            int xIndex = x;
            int yIndex = y;
            while((xIndex <= this.x1) && (yIndex <= this.y1)) {
                matrix[yIndex][xIndex] = '*';
                xIndex++;
                yIndex++;
            }
        } else if ((x > x1) && (y < y1)) {
            int xIndex = x;
            int yIndex = y;
            while((xIndex >= x1) && (yIndex <= y1)) {
                matrix[yIndex][xIndex] = '*';
                xIndex--;
                yIndex++;
            }
        } else if ((x < x1) && (y > y1)) {
            int xIndex = x;
            int yIndex = y; 
            while((xIndex <= x1) && (yIndex <= y1)) {
                matrix[yIndex][xIndex] = '*';
                xIndex++;
                yIndex--;
            }
        } else {
            int xIndex = x;
            int yIndex = y; 
            while((xIndex >= x1) && (yIndex >= y1)) {
                matrix[yIndex][xIndex] = '*';
                xIndex--;
                yIndex--;
            }
        }
    }

}
