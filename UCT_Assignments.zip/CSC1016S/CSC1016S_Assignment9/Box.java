public class Box extends Accessory {

    private int amountOfMemory;

    public Box() {}

    public Box(int serialNumber, String manufacturer, String color, int amountOfMemory) {
        super(serialNumber, manufacturer, color);
        this.amountOfMemory = amountOfMemory;
    }

    public Box(Box other) {
        super(other);
        this.amountOfMemory = other.getamountOfMemory();
    }

    public int getamountOfMemory() {return this.amountOfMemory;}

    public void setamountOfMemory(int amountOfMemory) {this.amountOfMemory = amountOfMemory;}

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Box)) {
            return false;
        } else {
            Box other = (Box)o;
            return (super.equals(other) && (this.amountOfMemory == other.getamountOfMemory()));
        }
    }

    @Override
    public String toString() {
        return (super.toString() + ", " + this.amountOfMemory);
    }



}
