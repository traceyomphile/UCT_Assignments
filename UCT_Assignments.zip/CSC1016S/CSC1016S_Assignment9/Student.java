public class Student extends Person {

    private String nameOfInstitution, programmeOfStudy, hobbies;
    private int yearOfStudy;

    public Student(String name, int age, String gender, String nameOfInstitution, String programmeOfStudy, int yearOfStudy, String hobbies) {
        super(name, age, gender);
        this.nameOfInstitution = nameOfInstitution;
        this.programmeOfStudy = programmeOfStudy;
        this.hobbies = hobbies;
        this.yearOfStudy = yearOfStudy;
    }

    public Student(Student other) {
        super(other);
        this.nameOfInstitution = other.getInstitution();
        this.programmeOfStudy = other.getProgramme();
        this.yearOfStudy = other.getYearOfStudy();
        this.hobbies = other.getHobbies();
    }

    public String getInstitution() {return this.nameOfInstitution;}

    public String getProgramme() {return this.programmeOfStudy;}

    public int getYearOfStudy() {return this.yearOfStudy;}

    public String getHobbies() {return this.hobbies;}

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Student)) {
            return false;
        } else {
            Student other = (Student)o;
            return (
                (super.equals(other)) &&
                (this.nameOfInstitution.equalsIgnoreCase(other.getInstitution())) &&
                (this.programmeOfStudy.equalsIgnoreCase(other.getProgramme())) &&
                (this.hobbies.equalsIgnoreCase(other.getHobbies())) &&
                (this.yearOfStudy == other.yearOfStudy)
            );
        }
    }

    @Override
    public String toString() {
        return (
            (super.toString() + " studying " + this.programmeOfStudy + " at " + this.nameOfInstitution + ". " + super.getName() + " likes " + this.hobbies + ".")
        );
    }

}
