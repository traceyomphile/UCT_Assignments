public class Person {

    private String name, gender;
    private int age;

    public Person(String name, int age, String gender) {
        this.name = name;
        this.age = age;
        this.gender = gender;
    }

    public Person(Person other) {
        this.name = other.getName();
        this.age = other.getAge();
        this.gender = other.getGender();
    }

    public String getName() {return this.name;}

    public int getAge() {return this.age;}

    public String getGender() {return this.gender;}

    public void setAge(int age) {this.age = age;}

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Person)) {
            return false;
        } else {
            Person other = (Person)o;
            return ((this.name.equalsIgnoreCase(other.getName())) && (this.gender.equalsIgnoreCase(other.getGender())) && (this.age == other.getAge()));
        }
    }

    @Override
    public String toString() {
        return (this.name + ", a " + this.age + "-year old " + this.gender);
    }

}
