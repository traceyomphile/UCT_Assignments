import java.util.Scanner;

public class SumCosts {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Currency currency = new Currency("R", "ZAR", 100);
        Money amount;
        
        Money sum = new Money("R0", currency);
        System.out.println("Enter an amount or \'[D]one\' to print the sum and quit:");
        String input = scanner.nextLine();
        while (input.charAt(0) != 'D' && input.charAt(0) != 'd') {
            amount = new Money(input, currency);
            sum = sum.add(amount);
            System.out.println("Enter an amount or \'[D]one\' to print the sum and quit:");
            input = scanner.nextLine();
        }
        scanner.close();

        System.out.println("Total: " + sum.toString());
    }

}
