import java.util.Scanner;

public class CalculateDuration {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter time A:");
        String stringA = scanner.nextLine();

        System.out.println("Enter time B:");
        String stringB = scanner.nextLine();
        scanner.close();

        Time timeA = new Time(stringA);
        Time timeB = new Time(stringB);

        long difference = timeB.subtract(timeA).intValue("minute");
        if (difference != 1) {
            System.out.println("The time " + timeB.toString() + " occurs " + difference + " minutes after the time " + timeA.toString() + ".");
        } else {
            System.out.println("The time " + timeB.toString() + " occurs " + difference + " minute after the time " + timeA.toString() + ".");
        }
    }  
}
