# Translating to a variant of Pig Latin
# Tracey Letlape
# 19 March 2024

# Get input from the user
a_str = input("Enter a sentence:\n")
a_str += ' '
a_str = a_str.lower()

# Assigning Variables
space = ' '
stop = a_str.count(' ')
result = ''
i = 0
s = 0

while i < stop:
    start_word = a_str[0: a_str.find(' ')]
    if start_word[0] == 'a' or start_word[0] == 'e' or start_word[0] == 'i' or start_word[0] == 'o' or start_word[0] == 'u':
        match = True
    else:
        match = False

    if match:
        result += start_word + 'way '
        a_str = a_str.replace(start_word+' ', '', 1)
        i += 1
    else:
        x = 0
        new_word = ''
        consonant = ''
        for n in start_word:
            if n == 'a' or n == 'e' or n == 'i' or n == 'o' or n == 'u':
                new_word += start_word[x: len(start_word)] + 'a' + consonant + 'ay '
                break
            else:
                consonant += n
                x += 1
                    
        result += new_word
        a_str = a_str.replace(start_word+' ', '', 1)
        i += 1
print(result)