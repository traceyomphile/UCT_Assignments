# Converting to 12 hour format
# Tracey Letlape
# 19 March 2024

# Get the user to enter the date and time in the format 'yyyy-mm-dd hh:mm'
a_str = input("Enter the date and time (yyyy-mm-dd hh:mm):\n")

# Extract the month number from the input through slicicng
month_number = int(a_str[5: 7])

# Map the month number to the corresponding month name
if month_number == 1:
    month = "January"
elif month_number == 2:
    month = "February"
elif month_number == 3:
    month = "March"
elif month_number == 4:
    month = "April"
elif month_number == 5:
    month = "May"
elif month_number == 6:
    month = "June"
elif month_number == 7:
    month = "July"
elif month_number == 8:
    month = "August"
elif month_number == 9:
    month = "September"
elif month_number == 10:
    month = "October"
elif month_number == 11:
    month = "November"
elif month_number == 12:
    month = "December"
else:
    month = "Invalid month"
    
# Extract the day from the input and determine the suffix to be assigned to the day
day = int(a_str[8: 10])
day_symbol = int(a_str[9: 10])
if day_symbol == 1 and day != 11:
    symbol = 'st'
elif day_symbol == 2 and day != 12:
    symbol = 'nd'
elif day_symbol == 3 and day != 13:
    symbol = 'rd'
elif 0 < day_symbol <= 31:
    symbol = 'th'
else:
    symbol = 'Inavild'
 
# Extract the hour and minutes from the input    
hour = int(a_str[11: 13])
minutes = a_str[14: 16]
minute = int(minutes)

# Determine whether it's 'am' or 'pm' based on the hour and minutes values
if minute >59:
    minute = -1
elif hour <= 11 and minute <= 59:
    time_symbol = 'am'
else:
    time_symbol = 'pm'

# Convert the hour to 12-hour format    
if 00 < hour <=12 :
    hour1 = hour
elif hour >12 :
    hour1 = hour - 12
elif hour == 00  :
    hour1 = 12
else:
    hour1 = -1

# Extract the year from the input
year = int(a_str[2: 4])

# Print the formatted date and time
if hour1 == -1 or month == 'Invalid month' or symbol == 'Invalid' or minute == -1:
    print("Invalid date and time provided")
elif year < 10:
    print(hour1, ":", minutes," ", time_symbol, " on the ", day, symbol, " of ", month, " \'", "0", year, sep='')
else:
    print(hour1, ":", minutes," ", time_symbol, " on the ", day, symbol, " of ", month, " \'", year, sep='')   
    