# Separating strings
# Tracey Letlape
# 19 March 2024

# Get the sentence from the user
a_str = input("Enter a sentence:\n")

# Assign variables 
space = ' '
new = ", "  
result = ""
i = 0

# Iterate through each character in the input string
while i < len(a_str):
    # Check if the current character matches the space character
    if a_str[i] != space:
        match = False
    else:
        match = True

    # If there's a match, replace with comma and a space
    if match:
        result += new
        i += 1
    else:
        # Otherwise, keep the original character
        result += a_str[i]
        i += 1

# Convert the result to lowercase and print it
print("The word list: ", result.lower(), ".", sep='')