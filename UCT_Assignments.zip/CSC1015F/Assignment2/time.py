# Validality of time entered by the user
# Assigned program
# Name: Tracey Letlape
# 28 February 2024

hours = eval(input("Enter the hours:\n" ))
minutes = eval(input("Enter the minutes:\n" ))
seconds =  eval(input("Enter the seconds:\n" ))
validTracker = 0  # The variable validTracker keeps track if all the necessary conditions have been met.

if (0 <= hours <= 23):
    validTracker = validTracker + 1
    if (0 <= minutes <= 59):
        validTracker = validTracker + 1
        if (0 <= seconds <= 59):
            validTracker = validTracker + 1

if validTracker == 3:
    print("Your time is valid.")
else:
    print("Your time is invalid.") # type: ignore