# Program to calculate user's strawars name
# (various sources)
# Stephan Jamieson
# edited by: Tracey Letlape, as per the assignment instructions
# February 2024

first_name = input("What\'s your first name?\n")
first_name = first_name.lower()

last_name = input("And what\'s your last name?\n")
last_name = last_name.lower()

maiden_name = input("And what\'s your mother\'s maiden name?\n")
maiden_name = maiden_name.lower()

city = input("Finally, where were you born?\n")
city = city.lower()

star_wars_first_name = first_name[:3] + last_name[:2]
star_wars_first_name = star_wars_first_name.capitalize()

star_wars_last_name = maiden_name[:2] + city[:3]
star_wars_last_name = star_wars_last_name.capitalize()

print('Your Star Wars name is', star_wars_first_name , star_wars_last_name)