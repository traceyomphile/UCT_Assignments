# Assigned program
# 01 March 2024
# Name: Tracey Letlape
# Calculating the loan amount to be repayed using the mathematical formula
# A = P(1 + ry)

P = eval(input("Enter the loan amount:\n")) # P is the loan amount
r = eval(input("Enter the annual interest rate:\n")) # r is the interest rate
y = eval(input("Enter the loan duration (years):\n")) # y is the duration in years
amount_tracker = 0 # used to keep track of boolean variables

if P > 0:
    amount_tracker = amount_tracker + 1
    if r > 0:
        amount_tracker = amount_tracker + 1
        if y > 0:
            amount_tracker = amount_tracker + 1

A = P * (1 + r * y) # A is the amount to be repayed

if amount_tracker == 3:
    print("The repayment amount is %.2f" % A, ".", sep='')
else:
    print("The values for amount, rate and duration must be greater than zero.")