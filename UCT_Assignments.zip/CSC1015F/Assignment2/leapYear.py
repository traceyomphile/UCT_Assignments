# Catergorising a year as a leap year or not
# Name: Tracey Letlape
# 28 February 2024

year = int(input("Enter a year:\n"))
true_tracker = 0
if (year % 400 == 0):# use % to determine the divisibility of the year
   true_tracker = true_tracker + 1
elif (year % 4 == 0 and year % 100 > 0): # use the and boolean operate as both conditions must be met for this to be true
      true_tracker = true_tracker + 1
elif (year % 4 == 0 and year % 400 == 0 and year % 100 == 0):
         true_tracker = true_tracker + 1
   
if (true_tracker == 1 or true_tracker == 2 or true_tracker == 3):
   print(year, "is a leap year.")
else:
   print(year,"is not a leap year.")