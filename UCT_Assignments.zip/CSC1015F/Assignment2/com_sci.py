# ASCII ART 
# Name: Tracey Letlape
# 28 Fberuary 2024

print("  ____ ____ ___ ____  _____ _   _ _   _ _", end="\n")   # use end="\n" to introduce a newline to ensure the output is as expected
print(" / ___/ ___|_ _/ ___||  ___| | | | \\ | | |", end="\n")   # Use \\ to escape the backslash character
print("| |   \\___ \\| |\\___ \\| |_  | | | |  \\| | |", end="\n")
print("| |___ ___) | | ___) |  _| | |_| | |\\  |_|", end="\n")
print(" \\____|____/___|____/|_|    \\___/|_| \\_(_)", end="\n")