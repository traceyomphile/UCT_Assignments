# A spam message
# Assigned program
# Name: Tracey Letlape
# 28 February 2024

first_name = input("Enter first name:\n" )
last_name = input("Enter last name:\n" )
sum_money = eval(input("Enter sum of money in USD:\n" ))
country = input("Enter country name:\n" )
print("")
print("Dearest" , first_name, end='\n') # use end='\n' to introduce a new line
print("It is with a heavy heart that I inform you of the death of my father,\nGeneral Fayk ", last_name,", your long lost relative from Mapsfostol.", end='\n', sep='')
print("My father left the sum of ", sum_money,"USD for us, your distant cousins.", sep='', end='\n') # use sep='' to remove the space between the variable used and the string that is to be the output
print("Unfortunately, we cannot access the money as it is in a bank in ", country,".", sep='',end='\n')
print("I desperately need your assistance to access this money.", end='\n')
print("I will even pay you generously, 30% of the amount - ", sum_money*0.3,"USD,\nfor your help.  Please get in touch with me at this email address asap.", sep='', end='\n') # use the // operation to ensure the number is realistic to the user and that they do not doubt the message
print("Yours sincerely", end='\n')
print("Frank", last_name)