# Merging items on a grid
# Tracey Letlape
# 12 April 2024

def push_up(grid):
    """merge grid values upwards"""
    merged = []
    for index in range(0, 4):
        merged.append([False, False, False, False])
    for index in range(len(grid[0])):
        # Check whether the above rows, strating from the second row, are empty.
        for item in range(1, len(grid)):
            # If not empty, check whether the item above it is empty.
            if grid[item][index] != 0:
                for k in range(item, 0, -1):
                    # If empty, move the item above and leave the current block empty. 
                    if grid[k - 1][index] == 0:
                        grid[k - 1][index] = grid[k][index]
                        grid[k][index] = 0
                    # If not empty and items are equal, merge the items once and move the sum up.
                    elif grid[k - 1][index] == grid[k][index] and not merged[k - 1][index]:
                        grid[k - 1][index] *= 2
                        grid[k][index] = 0
                        merged[k - 1][index] = True
                        break
                        
def push_down(grid):
    """merge grid values downwards"""
    merged = []
    for index in range(0, 4):
        merged.append([False, False, False, False])
    # Check whether the below rows, starting from the second last row, are empty.
    for item in range(len(grid) - 2, -1, -1):
        for index in range(len(grid[0])):
            # if not empty, check whether the item below it is empty.
            if grid[item][index] != 0:
                for k in range(item, len(grid) - 1):
                    # if empty, move the item down and leave the current block empty.
                    if grid[k + 1][index] == 0:
                        grid[k + 1][index] = grid[k][index]
                        grid[k][index] = 0
                    # if not empty and the items are equal, merge the items once and move them down. 
                    elif grid[k + 1][index] == grid[k][index] and not merged[k + 1][index]:
                        grid[k + 1][index] *= 2
                        grid[k][index] = 0
                        merged[k + 1][index] = True
                        break

def push_left(grid):
    """merge grid values left"""
    merged = []
    for index in range(0, 4):
        merged.append([False, False, False, False])
    for item in range(len(grid)):
        # check if items on the grid, starting from the second column, are empty.
        for index in range(1, len(grid[0])):
            # if not empty, check whether the blocks before the item are empty.
            if grid[item][index] != 0:
                for k in range(index, 0, -1):
                    # if empty, move the item to the left and leave the current block empty.
                    if grid[item][k - 1] == 0:
                        grid[item][k - 1] = grid[item][k]
                        grid[item][k] = 0
                    # if not empty and the items are equal, merge the items once and move them to the left.
                    elif grid[item][k - 1] == grid[item][k] and not merged[item][k - 1]:
                        grid[item][k - 1] *= 2
                        grid[item][k] = 0
                        merged[item][k - 1] = True
                        break

def push_right(grid):
    """merge grid values right"""
    merged = []
    for index in range(0, 4):
        merged.append([False, False, False, False])
    for item in range(len(grid)):
        # check if items on the grid, starting from the second last column, are empty.
        for index in range(len(grid[0]) - 2, -1, -1):
            # if not empty, check whether the blocks after the item are empty.
            if grid[item][index] != 0:
                for k in range(index, len(grid[0]) - 1):
                    # if empty, move the item to the right and leave the current block empty.
                    if grid[item][k + 1] == 0:
                        grid[item][k + 1] = grid[item][k]
                        grid[item][k] = 0
                    # if not empty and the items are equal, merge the items once and move them to the right.
                    elif grid[item][k + 1] == grid[item][k] and not merged[item][k+1]:
                        grid[item][k + 1] *= 2
                        grid[item][k] = 0
                        merged[item][k + 1] = True
                        break