# Module of utility functions for manipulating 2-D arrays of size 4x4
# Tracey Letlape
# 10 April 2024

import copy

def create_grid(grid):
    """create a 4x4 array of zeroes within"""
    for index in range(0, 4):
        grid.append([0, 0, 0, 0])

def print_grid(grid):
    """Print out a 4x4 array of grid in 5-width columns within a box."""
    print("+", "-" * 20, "+", sep='')
    for index in grid:
        print("|", end='')
        for item in index:
            if item != 0:
                print(f'{item:<5}', end='')
            else:
                print(f'{"":<5}', end='')
        print("|")
    print("+", "-" * 20, "+", sep='')

def check_lost(grid):
    """return True if there are no 0 values and there are no
    adjacent values that are equal; otherwise False"""
    for i in range(len(grid)):
        for j in range(len(grid[0])):
            if grid[i][j] == 0:
                return False
            # check for same cell on right
            if j < len(grid[0]) - 1 and grid[i][j] == grid[i][j + 1]:
                return False
            # check for same cell below
            if i < len(grid) - 1 and grid[i][j] == grid[i + 1][j]:
                return False
    return True

def check_won(grid):
    """return True if a value>=32 is found in the grid; otherwise
    False"""
    for index in grid:
        for item in index:
            if item >= 32:
                return True
    return False

def copy_grid(grid):
    """return a copy of the given grid"""
    return copy.deepcopy(grid)

def grid_equal(grid1, grid2):
    """check if 2 grids are equal - return boolean value"""
    return grid1 == grid2