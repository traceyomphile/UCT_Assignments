# Testing format
# Tracey Letlape
# 12 April 2024

"""
>>> import format
>>> format.time_str(2, 0)
"2 o'clock"
>>> format.time_str(6, 30)
'half past 6'
>>> format.time_str(11, 24)
'24 minutes past 11'
>>> format.time_str(3, 46)
'14 minutes to 4'
>>> format.time_str(12, 52)
'8 minutes to 1'
>>> format.time_str(8, 59)
'1 minute to 9'
>>> format.time_str(7, 1)
'1 minute past 7'
>>> format.time_str(12, 59)
'1 minute to 1'

"""
import doctest
doctest.testmod(verbose=True)