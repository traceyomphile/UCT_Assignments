# Histogram representation of marks according to the mark categories
# Tracey Letlape
# 10 April 2024

def _list(marks):
    """stores the list of marks, in their integer type, in a list"""
    marks = marks.split(' ')
    return [int(a) for a in marks if a != ' ']

def first(marks):
    """returns the number of marks within the first class category"""
    marks = _list(marks)
    return len([a for a in marks if 75 <= a <= 100])

def upper_2nd(marks):
    """returns the number of marks within the upper 2nd category"""
    marks = _list(marks)
    return len([a for a in marks if 70 <= a < 75])

def lower_2nd(marks):
    """return the number of marks within the lower 2nd category"""
    marks = _list(marks)
    return len([a for a in marks if 60 <= a < 70])

def third(marks):
    """returns the number of marks with the third class category"""
    marks = _list(marks)
    return len([a for a in marks if 50 <= a < 60])

def fail(marks):
    """returns the number of marks within the Fail category"""
    marks = _list(marks)
    return len([a for a in marks if 0 <= a < 50])

def histogram(marks):
    """prints out horizontal bars, using X, of the representation of the marks"""
    print("1 |", 'X'*first(marks), sep='')
    print("2+|", 'X'*upper_2nd(marks), sep='')
    print("2-|", 'X'*lower_2nd(marks), sep='')
    print("3 |", 'X'*third(marks), sep='')
    print("F |", 'X'*fail(marks), sep='')

def main():
    """prompts the user for input and displays the results"""
    marks = input("Enter a space-separated list of marks:\n")
    histogram(marks)
    
if __name__ == '__main__':
    main()