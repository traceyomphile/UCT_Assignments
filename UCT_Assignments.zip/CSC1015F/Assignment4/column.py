# Assigned Program
# Tracey Letlape
# 11 March 2024

# Input from the use
n = eval(input("Enter a number between -6 and 2:\n"))

# Selection

if -6 <= n <= 2:
 for i in range(n, n+41, 7):
    if 0 <= i <= 9:
        print(" ", i, sep='')
    else:
        print(i, sep='')
else:
 print("Invalid input! The value of \'n\' should be between -6 and 2.") # escape character