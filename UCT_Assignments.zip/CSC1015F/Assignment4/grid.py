# Assigned Program
# Tracey Letlape
# 11 March 2024

# Input from the user

n = eval(input("Enter a number between -6 and 2:\n"))

# Selection and Repetition

if -6 <= n <= 2:
    for i in range(n, n+7):
        if 0 <= i <= 9:
            print(" ", i, sep='', end=' ')
        else:
            print(i, sep='', end=' ')
    print(end='\n')
    for j in range(n+7, n+14):
        if 0 <= j <= 9:
            print(" ", j, sep='', end=' ')
        else:
            print(j, sep='', end=' ')
    print(end='\n')
    for k in range(n+14, n+21):
        if 0 <= k <= 9:
            print(" ", k, sep='', end=' ')
        else:
            print(k, sep='', end=' ')
    print(end='\n')
    for l in range(n+21, n+28):
        if 0 <= l <= 9:
            print(" ", l, sep='', end=' ')
        else:
            print(l, sep='', end=' ')
    print(end='\n')
    for m in range(n+28, n+35):
        if 0 <= m <= 9:
            print(" ", m, sep='', end=' ')
        else:
            print(m, sep='', end=' ')
    print(end='\n')
    for o in range(n+35, n+42):
        if 0 <= o <= 9:
            print(" ", o, sep='', end=' ')
        else:
            print(o, sep='', end=' ')
else:
    print("Invalid input! The value of \'n\' should be between -6 and 2.")