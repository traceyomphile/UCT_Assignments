# Assigned program
# Tracey Letlape
# 10 March 2024

# Input from the user
n = eval(input("Enter a number between -6 and 93:\n"))

# Selection
if -6 <= n <= 93:    
 for i in range(n, (n+7)):
    if 0 <= i <= 9:
        print(" ", i, sep='', end=' ')
    else:
        print(i, sep='', end=' ')
else:
    print("Invalid input! The value of \'n\' should be between -6 and 93.")