# Caculating the volume of the sphere
# Tracey Letlape
# 05 April 2024

from math import pi, pow
# Defining functions
def volume(radius):
    """Given the radius, return the volume of the sphere"""
    volume = (4 * pi * pow(radius, 3))/3
    return volume
        
def main():
    """Prompt the user for input and print out the output"""
    radius = eval(input("Enter the radius of the sphere:\n"))
    if radius >= 0:
        print("The volume is ", "%.2f" % volume(radius), ".", sep='')
    else:
        print("The radius must not be a negative value.")
       
if __name__ == '__main__':
    main()