# Extracting useful data from raw data obtained from sensor
# Tracey Letlape
# 01 April 2024

# Defining functions
def location(block):
    """Return the location"""
    # Extract the manipulative part of the block
    c = block[block.find(":"):]
    a_str = ''
    for i in c:
        if i == ' ': # Finding the beginning of the location from the block
            a_str += c[c.find(i):] 
            break
        
    # Extract the location information from the block
    a_str = a_str[1:a_str.find("END")-1]
    # Reverse the string and title case it
    return a_str[::-1].title()

def temperature(block):
    """Extract the temperature value from the block and return it's numerical value"""
    return float(block[block.find(" "): block.find("_")])


def x_coordinate(block):
    """Extract and return the x-coordinate from the block"""
    return block[block.find(":")+1: block.find(",")]


def y_coordinate(block):
    """Extract and return the y-coordinate from the block"""
    c = block.replace("BEGIN ", "")
    return c[c.find(",")+1: c.find(" ")]


def pressure(block):
    """Extract the pressure value from the block and return it's numerical value"""
    return float(block[block.find("_")+1: block.find(":")])


def get_block(data):
    """Extract the useful data(block) from the raw data"""
    return data[data.find("BEGIN"): data.find("END")+3]


def main():
    # prompt the user for input
    data = input('Enter the raw data:\n')
    block = get_block(data)
    print('Site information:')
    print('Location:', location(block))
    print('Coordinates:', y_coordinate(block), x_coordinate(block))
    print('Temperature: {:.2f} C'.format(temperature(block)))
    print('Pressure: {:.2f} hPa'.format(pressure(block)))

# Creating a module
if __name__=='__main__':
    main()