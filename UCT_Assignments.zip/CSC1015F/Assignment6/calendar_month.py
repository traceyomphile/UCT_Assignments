# Printing out the calendar fot the month
# Tracey Letlape
# 04 April 2024

# Defining functions
def day_of_week(day, month, year):
    """Calculate the day of the week for a given day, month, year using Zeller's Congruence algorithm"""
    import math
    # Assign variables to make the calculation mathematically readable
    m = month
    y = year
    # Using Zeller's congruence to find the day of week
    if 0 < m < 3:
        m += 12
        y -= 1
        
    h = (day + math.floor((13*(m+1)/5)) + y + math.floor(y/4) - math.floor(y/100) + math.floor(year/400)) % 7
    # Return day of week
    return ((h + 5) % 7) + 1

def is_leap(year):
    """Returns True if the given year is a leap year and False otherwise"""
    return year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)

def month_num(month_name):
    """Return a int number associated with a given month"""
    month_name = month_name.title()
    if month_name == 'January':
        return 1
    elif month_name == 'February':
        return 2
    elif month_name == 'March':
        return 3
    elif month_name == 'April':
        return 4
    elif month_name == 'May':
        return 5
    elif month_name == 'June':
        return 6
    elif month_name == 'July':
        return 7
    elif month_name == 'August':
        return 8
    elif month_name == 'September':
        return 9
    elif month_name == 'October':
        return 10
    elif month_name == 'November':
        return 11
    elif month_name == 'December':
        return 12
    else:
        return "Invalid month"

def num_days_in(month_num, year):
    """Returns the number of days in a given month"""
    if month_num == 1:
        return 31
    elif month_num == 3:
        return 31
    elif month_num == 4:
        return 30
    elif month_num == 5:
        return 31
    elif month_num == 6:
        return 30
    elif month_num == 7:
        return 31
    elif month_num == 8:
        return 31
    elif month_num == 9:
        return 30
    elif month_num == 10:
        return 31
    elif month_num == 11:
        return 30
    elif month_num == 12:
        return 31
    return 29 if is_leap(year) and month_num == 2 else 28   # Ternary operator

def num_weeks(month_num, year):
    """Returns the number of weeks in a given month"""
    import math
    # Invoking functions
    days_in_month = num_days_in(month_num, year)
    start_day = day_of_week(1, month_num, year)
    # Calculating the number of weeks in a given month and year
    days_in_month += start_day - 1
    return math.ceil(days_in_month/7)
    
def week(week_num, start_day, days_in_month):
    """Returns a string of the days of a week given"""
    # Initialize an empty string to build up on
    week_str = ''
    # Iterate through 7 days of a given week
    for i in range(1, 8):
        # Determine which day of a month is it
        day_of_month = week_num * 7 - 7 - (start_day-1) + i
        if 0 < day_of_month <= days_in_month:
            if day_of_month < 10:
                # Increment the week string with the day_of_month as a string type
                week_str += f" {str(day_of_month)} "
            else:
                week_str += f"{str(day_of_month)} "
        else:
            # If day_of_month is outside the rage, increment by three spaces
            week_str += "   "
    # return the week string
    return week_str
            
def main():
    """Obtains the month name and the year from the user and prints out the calendar for that month"""
    month = input("Enter month:\n")
    year = int(input("Enter year:\n"))
    # Start of the day for which month is the 1st, store this in a variable
    start_day = day_of_week(1, month_num(month), year)
    print(month.title())
    print("Mo Tu We Th Fr Sa Su")
    # Iterate through each and every week of the weeks of the month
    for i in range(1, num_weeks(month_num(month), year) + 1):
        print(week(i, day_of_week(1, month_num(month), year), num_days_in(month_num(month), year)))

if __name__=='__main__':
    main()