# Given a word, calculate how many syllables it contains.
# Tracey Letlape
# 02 April 2024

def count_syllables(word):
    """ counts the number of syllables in a word and returns it"""
    # Assigning variables
    count = 0
    word = f'{word.lower()} '   # Format the word to allow for iteration
    vowels = 'aeiouy'
    i = 0
    # Iterate through every character in the word
    for i in range(len(word)):
        char = word[i]
        if char in vowels:
            next_char = word[i+1]
            count += 0 if next_char in vowels else 1
        else:
            count += 0
    # Disregard last char 'e' if it is not the only syllable
    if count > 1:
        if word[-3] not in vowels and word[-2] == 'e':       
            count -= 1
    return count
        
def main():
    """prompts the user to enter a word or quit
    evaluates the number of syllables
    print out the results"""
    # Prompt the user for input
    word = input('Enter a word (or \'q\' to quit):\n')
    # Check the input provided by the user
    while word != 'q':
        # Invoke the count_syllable
        count = count_syllables(word)
        # Output the results
        if count > 1:
            print("The word \'", word, "\' has ", count, " syllables", ".", sep='')
        else:
            print("The word \'", word, "\' has ", count, " syllable", ".", sep='')
        print()
        word = input('Enter a word (or \'q\' to quit):\n')   

if __name__ == '__main__':
    main()