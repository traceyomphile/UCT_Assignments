# Check if a given pattern matches the given word
# Tracey Letlape
# 20 April 2024

def match(pattern, word):
    """determine if a given word matches a given word"""
    # Base case, if both strings are empty, return True
    if len(word) == 0 and len(pattern) == 0:
        return True
    # if only one is empty, it's not a match
    if len(pattern) == 0 or len(word) == 0:
        return False
    # Check if strings are of equal lengths
    if len(pattern) == len(word):
        # Check if the characters match or pattern has a wildcards: "?" , "*"
        if pattern[0] == word[0] or pattern[0] == '?' or pattern[0] == '*':
            return match(pattern[1:], word[1:])
        # If characters do not match and there are no wildcards, it's not a match
        else:
            return False
    # If strings are not of equal lengths
    else:
        # Check if the characters match or pattern has a wildcard: "?"
        if pattern[0] == word[0] or pattern[0] == '?':
            return match(pattern[1:], word[1:])
        # If pattern has "*", ignore it and move to the next character in word
        elif pattern[0] == '*':
            return match(pattern, word[1:]) or match(pattern[1:], word) or match(pattern[1:], word[1:])
        # If characters do not match and there are no wildcards, return False
        else:
            return False