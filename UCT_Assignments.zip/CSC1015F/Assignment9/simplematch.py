# Check whether a given pattern corresponds a given word
# Tracey Letlape
# 17 April 2024

def match(pattern, word):
    """check whther a given pattern matches a given word"""
    # Base case: both the pattern and word strings are empty, return True
    if len(pattern) == 0 and len(word) == 0:
            return True
    # If only one of the two strings is emoty, return False
    if len(pattern) == 0 or len(word) == 0:
         return False
    # If both the pattern and the word are of the same length
    if len(pattern) == len(word):
        # Check if the characters match or pattern has "?"
        if pattern[0] == word[0] or pattern[0] == '?':
            return match(pattern[1:], word[1:])
        # If characters do not match and no "?" in pattern, then return False
        else:
            return False
    # If the lengths of the two are not equal, return False
    else:
         return False