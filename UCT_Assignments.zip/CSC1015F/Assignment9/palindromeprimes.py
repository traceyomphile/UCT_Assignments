# Palindrome primes
# Tracey Letlape
# 21 April 2024

import sys
sys.setrecursionlimit(30000)

def prime(num, divisor=2):
    """Checks if a number is a prime number and returns a boolean value"""
    # Base case, 1 is not a prime number.
    if num < 2:
        return False
    if num == 2:
        return True
    # Another base case: If a number is divisible by some other number, it's not a prime.
    if num % divisor == 0:
        return False
    # Recursive case, check the next divisor
    if divisor * divisor <= num:
        return prime(num, divisor+1)
    # If a number is not divisible by any other number, then it is a Prime
    else:
        return True
    
def palindrome(string):
    """Checks if a number is a palindrome and returns a corresponding boolean"""
    # Base case, one character strings are palindromes
    if len(string) == 1:
        return True
    # Another base case: if the string is empty, return True
    if len(string) == 0:
        return True
    # If the first and the last characters are the same, recursively check other middle characters
    if string[0] == string[-1]:
        return palindrome(string[1: len(string)-1])
    # If they are not the same, return False
    else:
        return False
   
def palindromic_primes(N, M):
    """prints out palindromic primes"""
    # Base case: N must be less than or equal to M
    if N > M:
        return False
    else:
        # If N is both a palindrome and a prime, print out N
        if palindrome(str(N)) and prime(N):
            print(N)
        # Check the next number after N, the end point remains.
        palindromic_primes(N + 1, M)

def main():
    """prompts the user for input and prints out the results"""
    N = int(input("Enter the starting point N:\n"))
    M = int(input("Enter the ending point M:\n"))
    print("The palindromic primes are:")
    palindromic_primes(N, M)

if __name__ == '__main__':
    main()