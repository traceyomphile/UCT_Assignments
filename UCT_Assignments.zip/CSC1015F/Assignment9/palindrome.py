# Check whether a word is a palindrome
# Tracey Letlape
# 17 April 2024

def palindrome(string):
    """Checks if a given string is a palindrome"""
    # Cases do not matter, convert every character to lower cases
    string = string.lower()
    # Base case, one character strings are palindromes
    if len(string) == 1:
        return True
    # Another base case: if the string is empty, return True
    if len(string) == 0:
        return True
    # If the first and the last characters are the same, recursively check other middle characters
    if string[0] == string[-1]:
        return palindrome(string[1: len(string)-1])
    # If they are not the same, return False
    else:
        return False
        
def main():
    """prompts the user for input and outputs the results"""
    string = input("Enter a string:\n")
    if palindrome(string):
        print("Palindrome!")
    else:
        print("Not a palindrome!")

if __name__ == '__main__':
    main()