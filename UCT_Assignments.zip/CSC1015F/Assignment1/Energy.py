# Calculating energy
# Name: Tracey Letlape
# Date: 23 February 2024

m = eval(input("Enter the value of m:\n"))
c = eval(input("Enter the value of c:\n"))
E = m * c**2
print("The value of energy, E, is:", E)