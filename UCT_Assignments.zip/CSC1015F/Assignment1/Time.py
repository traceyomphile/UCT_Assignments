# Program to convert an amount of minutes into an equivalent amount
# of days, hours and minutes.
#
# Name: Stephan Jamieson
# Edited by: Tracey Letlape
# Date : 23 February 2024

input_str = input("Enter a quantity of minutes: ")
minutes = int(input_str)
minute = minutes%60
hours = minutes//60
hour = hours%24
days = hours//24
print("The number of days is", days, end=', ')
print("the number hours is", hour, end=', ')
print("and the number of minutes is", minute, end='')
print(".")