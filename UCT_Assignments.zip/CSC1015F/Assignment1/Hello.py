# First ever programme. 
# Name: Tracey Letlape
# Student Number: LTLTRA001
# 19 February 2024

print("Hello World")