# Anagram Set Search
# Tracey Letlape
# 25 April 2024

def Englishwords():
    """Returns a list of English words from a file."""
    try:
        # open file on read mode using UTF-8 encoding.
        file_link = open("EnglishWords.txt", "r", encoding='utf-8')
        # Read all contents of the file into one string.
        all_Text = file_link.read()
        # Close the file once you done.
        file_link.close()
        # Exclude the copyright and extract only the english words into a list.
        English_words = all_Text[all_Text.find("START"):].lower()
        # Return a list of English words.
        return English_words.split()
    # Raise an exception if the file is not found, print out a message.
    except FileNotFoundError:
        print("File Not Found.")
        return []

def WordsInLength(englishwords, len_word):
    """Returns a dictionary of anagram english words that are of the length
    the user wishes to search for"""
    words_in_len = {}
    # Iterate through all English words.
    for word in englishwords:
        # Check if the word is of the length provided by the user.
        if len(word) == len_word:
            # Check if the words are anagrams.
            sorted_word = ''.join(sorted(word))
            # Assign the sorted word the value of word as a list. 
            if sorted_word not in words_in_len:
                words_in_len[sorted_word] = [word]
            # If the sorted word key is in the dictionary, append the word to the value.
            else:
                words_in_len[sorted_word].append(word)
    # Return the dictionary of the words in length that are anagrams.
    return words_in_len

def anagram_sets(words_in_len):
    """Returns anagram sets of all the words in the given length"""
    anagramsets = []
    # Iterate through all words in the dictionary that have anagrams.
    for key in words_in_len:
        # If the word has more than one anagram (meaning besides the word itself),
        if len(words_in_len[key]) > 1:
            # Append the sorted value of that word to the anagramsets list.
            anagramsets.append(sorted(words_in_len[key]))
    # Return the sorted list of anagramsets.
    return sorted(anagramsets)


def WriteToFile(filename, anagramsets):
    """Writes the sets to the file given by the user"""
    try:
        # Open the file on write mode to overwrite the file or create one if not found.
        filelink = open(filename, "w")
        # Iterate through the list of anagramsets.
        for item in anagramsets:
            # Write each list of anagramsets on a newline.
            print(item, file=filelink)
        # Close the file once done writing.
        filelink.close()
    # Raise an exception if an error occured with a message.
    except IOError:
        print("Error writing to file.")

def main():
    """Prompts the user for input and writes the results"""
    print("***** Anagram Set Search *****")
    try:
        len_word = int(input("Enter word length:\n"))
        print("Searching. . .")
        englishwords = Englishwords()
        words_in_len = WordsInLength(englishwords, len_word)
        anagramsets = anagram_sets(words_in_len)
        user_file = input("Enter file name:\n")
        print("Writing results. . .")
        WriteToFile(user_file, anagramsets)
    # Raise an exception with a message if an invalid integer entered.
    except ValueError:
        print("Invalid input. Enter valid integer.")

if __name__ == '__main__':
    main()