# Tracer program used to assist in debugging
# Tracey Letlape
# 30 April 2024

def accessingfile(filename):
    """Reads the contents of a file into a list of strings"""
    try:
        # Open the file on read mode.
        filelink = open(filename, "r", encoding='utf-8')
        # Read all contents of the file into a list of strings.
        contents = filelink.readlines()
        # Close the file once done.
        filelink.close()
        # Return the list of the contents of the file.
        return contents
    # Raise an exception if file not found, return nothing.
    except FileNotFoundError:
        print("File not found.")
        return

def FixTraceStatements(contents):
    """Inserts Trace Statements if the function does not contain any"""
    if '"""' not in contents[0]:
        # Insert trace statement.
        contents.insert(0, '"""DEBUG"""\n')
    else:
        # Else remove it.
        contents.remove(contents[0])
    # Iterate through the contents of the file.
    for item in contents:
        next = contents.index(item)+1
        # Check if the line is a function header.
        if 'def ' in item:
            # Check if the next line contains a docstring.
            if '"""' not in contents[next]:
                functionname = item[4: item.find("(")]
                # If not, Insert a trace statement and also print out the function's name.
                contents.insert(next, '    """DEBUG""";'+'print('+"'"+functionname+"'"+')'+'\n')
            else:
                # Else remove the trace statements.
                contents.remove(contents[next])
    # Return the list of items that contain trace statements.
    return contents

def CheckingForTraceStatements(contents):
    """Returns True if a trace statement is found or False if otherwise."""
    # Iterate through the list of contents.
    for item in contents:
        next = contents.index(item)+1
        # Check if a line is a function header.
        if 'def ' in item:
            # Return False if the next line does not contain docstrings.
            if '"""' not in contents[next]:
                return False
    # Return True otherwise
    return True
    
def WritingToFile(filename, contents):
    """Overwrites the file with the updated version"""
    try:
        # Open the file on overwrite mode to clear the file.
        filelink = open(filename, "w")
        # Write each and every line on a new line.
        for item in contents:
            print(item, file=filelink, end='')
        # Close the file once done
        filelink.close()
    # Raise an exception if an error occured.
    except FileNotFoundError:
        print("Error writing to file")

def main():
    """Prompts the user for input and outputs the results"""
    print("***** Program Trace Utility *****")
    try:
        # Ask the user for the name of the file
        filename = input("Enter the name of the program file: ")
        info = accessingfile(filename)
        if info:
        # Check if file conatins trace statements
            if CheckingForTraceStatements(info):
                print("Program contains trace statements")
                # Remove trace statemnts if found.
                WritingToFile(filename, FixTraceStatements(info))
                print("Removing. . .Done")
            else:
                # Insert trace statements if not found
                WritingToFile(filename, FixTraceStatements(info))
                print("Inserting. . .Done")
    # Raise an exception if file not found.
    except FileNotFoundError:
        print("Error writing to file.")

if __name__ == '__main__':
    main()