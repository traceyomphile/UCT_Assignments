# Anagrams search
# Tracey Letlape
# 25 April 2024

print("***** Anagram Finder *****")
try:
    file_link = open("EnglishWords.txt", "r", encoding='utf-8')
    # Read data in a file and store it into a single string
    all_Text = file_link.read()
    file_link.close()
    # Skip the copyright notice and start from the line START
    English_words = all_Text[all_Text.find("START"):].lower()
    # Convert all words in to a list
    English_words = English_words.split()
    # Prompt the user for input and convet it to lower case
    word = input("Enter a word:\n").lower()
    dict = {}
    # Store each letter and it's frequency in the dictionary
    for char in word:
        if char not in dict:
            dict[char] = 1
        else:
            dict[char] += 1
    anagrams = []
    # Iterate through every English word from the file
    for words in English_words:
        # Create a dictionary for every word while iterating
        dictionary = {}
        # Store each letter in a word and it's freququency in the dictionary
        for char in words:
            if char not in dictionary:
                dictionary[char] = 1
            else:
                dictionary[char] += 1
        # Append the word to the anagram list if the word is an anagram
        if dict == dictionary:
            anagrams.append(words)
    if word in anagrams:
    # Remove the original word from the list and store only it's anagrams
        anagrams.remove(word)
    # If no anagram found, print the following message
    if anagrams == []:
        print("Sorry, anagrams of \'", word, "\' could not be found.", sep ='')
    # Else, print out the sorted list
    else:
        print(sorted(anagrams))
# Use exception handling to allow the program to crash gracefully
except FileNotFoundError:
    print("Sorry, could not find file \'EnglishWords.txt\'.")