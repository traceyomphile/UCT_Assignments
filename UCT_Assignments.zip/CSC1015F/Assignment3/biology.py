# Determing the type of animal
# Tracey Letlape
# Assigned program
# 02 March 2024


print("Welcome to the Biology Expert")
print("-----------------------------")
print("Answer the following questions by selecting from among the options.")
skeleton = "internal"  # use boolean variables to assist with manipuation of the user's inputs
fertilisation = "within the body" 
skin = "scales"
young = "waterproof eggs"
habitat = "in water"
real_skeleton = input("The skeleton is (internal/external)?\n")
if real_skeleton == skeleton:
    real_fertilisation = input("The fertilisation of eggs occurs (within the body/outside the body)?\n")
    if real_fertilisation == fertilisation:
        real_young = input("Young are produced by (waterproof eggs/live birth)?\n")
        if real_young == young:
            real_skin = input("The skin is covered by (scales/feathers)?\n")
            if real_skin == skin:
                print("Type of animal: Reptile")
            else:
                print("Type of animal: Bird")
        else:
            print("Type of animal: Mammal")
    else:
        real_habitat = input("It lives (in water/near water)?\n")
        if real_habitat == habitat:
            print("Type of animal: Fish")
        else:
            print("Type of animal: Amphibian")
else:
    print("Type of animal: Arthropod")