# Check if a set of six numbers is a pair of GPS coordinates or not
# Tracey Letlape
# Assigned program
# 04 March 2024

lat_degrees = eval(input("Enter first number:\n"))
lat_minutes = eval(input("Enter second number:\n"))
lat_seconds = eval(input("Enter third number:\n"))
lon_degrees = eval(input("Enter fourth number:\n"))
lon_minutes = eval(input("Enter fifth number:\n"))
lon_seconds = eval(input("Enter sixth number:\n"))
true_tracker = 0 # to keep track of the correct infomation added by the user

# evaluation information from the user
if -90 <= lat_degrees <= 90 and -180 <= lon_degrees <= 180: # both must be true
    true_tracker = true_tracker + 1
    if 0 <= lat_minutes <= 59 and 0 <= lon_minutes <= 59:
        true_tracker = true_tracker + 1
        if 0 <= lat_seconds <= 59 and 0 <= lon_seconds <= 59:
            true_tracker = true_tracker + 1
        
if true_tracker == 3:
    print("WOW! Looks like geographic coordinates!")
else:
    print("Hmmm ... looks like 6 random numbers.")