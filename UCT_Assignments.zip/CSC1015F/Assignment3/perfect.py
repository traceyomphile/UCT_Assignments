# Determine whether a number is a perfect number or not
# Tracey Letlape
# Assigned program
# 04 March 2024

num = eval(input("Enter a number:\n"))
print("The proper divisors of", num, "are:")
for x in range (1, num):
  if num%x==0:   # use the modulas operator. Proper divisors should leave no remainder
    print(x, end=" ") # to ensure that all proper divisors are on the same line. 

sum_num = 0 # assign the sum a value of zero and allow it to accumulate. 
for x in range(1, num):  # use the same loop to determine the sum
  if num%x==0:
    sum_num += x
if sum_num == num:
  print("\n")
  print(num, "is a perfect number.")
else:
  print("\n")
  print(num, "is not a perfect number.")