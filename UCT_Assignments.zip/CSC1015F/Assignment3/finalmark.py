# Calculates and prints the final mark of the marks given by the user
# Assigned program
# 08 March 2024

prac_mark_ = eval(input("Enter the mark for practical work:\n"))
classtests_ = eval(input("Enter the mark for class tests:\n"))
final_exam_ = eval(input("Enter the mark for the final exam:\n"))
true_tracker = 0
if 0 <= prac_mark_ <= 100:
    true_tracker = true_tracker + 1
    if 0 <= classtests_ <= 100:
        true_tracker = true_tracker + 1
        if 0 <= final_exam_ <= 100:
            true_tracker = true_tracker + 1

# Final mark calculation

if true_tracker == 3:
    final_mark = 0.5 * final_exam_ + 0.2 * classtests_ + 0.3 * prac_mark_ 
else:
    final_mark = 0
    print("Marks must be in the range 0 to 100.")

# Output to the user
import math
if 75 <= final_mark <= 100:
    print("The final mark is %.1f" % final_mark, ".", sep='')
    print("This mark is graded as a 1st.")
elif 60<= final_mark < 75:
    print("The final mark is %.1f" % final_mark, ".", sep='')
    print("This mark is graded as a 2nd.")
elif 50 <= final_mark < 60:
    print("The final mark is %.1f" % final_mark, ".", sep='')
    print("This mark is graded as a 3rd.")
elif 0 < final_mark < 50:
    print("The final mark is %.1f" % final_mark, ".", sep='')
    print("This mark is graded as a Fail.")