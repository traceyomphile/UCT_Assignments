# Testing numberutil
# Tracey Letlape
# 08 April 2024

# testnumberutil.py
"""
>>> import numberutil
>>> numberutil.aswords(0)
'zero'
>>> numberutil.aswords(999)
'nine hundred and ninety nine'
>>> numberutil.aswords(12)
'twelve'
>>> numberutil.aswords(45)
'forty five'
>>> numberutil.aswords(202)
'two hundred and two'
>>> numberutil.aswords(60)
'sixty'
>>> numberutil.aswords(360)
'three hundred and sixty'
>>> numberutil.aswords(100)
'one hundred'

"""
import doctest
doctest.testmod(verbose=True)