# Testing timeutil
# Tracey Letlape
# 8 April 2024

# test timeutil.py
"""
>>> import timeutil
>>> timeutil.validate(':2p.m')
False
>>> timeutil.validate('two:24 p.m')
False
>>> timeutil.validate('01:25 p.m.')
False
>>> timeutil.validate('8:30 pm.')
False
>>> timeutil.validate('11:600 p.m.')
False
>>> timeutil.validate('12:00 a.m.')
True

"""

import doctest
doctest.testmod(verbose=True)