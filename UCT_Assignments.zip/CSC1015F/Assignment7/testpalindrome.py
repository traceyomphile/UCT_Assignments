# Testing palindrome.py
# Tracey Letlape
# 8 April 2024

# testpalindrome.py
"""
>>> import palindrome
>>> palindrome.is_palindrome('a')
True
>>> palindrome.is_palindrome('mala y alam')
True
>>> palindrome.is_palindrome('545')
True
>>> palindrome.is_palindrome('123')
False
>>> palindrome.is_palindrome('')
True

"""
import doctest
doctest.testmod(verbose=True)