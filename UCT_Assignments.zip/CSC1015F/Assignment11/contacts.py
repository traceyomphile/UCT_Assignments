# Consolidation assignment
# Tracey Letlape
# 04 May 2024

import os

def path_exists(file_path):
    """Return True if path is found and False otherwise."""
    return os.path.exists(file_path)

def check_contact(file_path, query):
    """Returns a list of contacts found depending on the query provided."""
    contacts = custom_sort(read_contacts(file_path))
    found_contacts = []
    # Iterate through each contact in contacts.
    for contact in contacts:
        # Initially no contact is found, set it to false.
        contact_found = False
        # Iterate through the info of a contact. 
        for con_detail in contact:
            if query in con_detail:
                found_contacts.append(contact)
                contact_found = True
                break
            # If space in the info, split the info.
            con_list = con_detail.split(' ')
            # For each item in a list, check if the query matches the item.
            for con in con_list:
                if wildcard(query, con):
                    found_contacts.append(contact)  # Append if match.
                    # Contact is found, set to true.
                    contact_found = True
                    # Break the info loop.
                    break
            # Contact is found, break the current loop and move to the next contact.
            if contact_found: break
    return found_contacts

def add_contact(file_path, name, phone, email):
    """Adds contact to a file and returns a message as a string."""
    # Open file on append mode.
    if check_contact(file_path, name) and check_contact(file_path, phone) and check_contact(file_path, email):
        return 'Contact already exists.'
    else:
        filelink = open(file_path, "a")
        print(f'{name}, {phone}, {email}', file=filelink)  # Write to file using print.
        filelink.close()
        return 'Contact added successfully.'

def custom_sort(contacts):
    """Sorts the contact list alphabetically by name using linear search."""
    for i in range(len(contacts)):
        minimum = i  # Assume the current position is the minimum.
        # Compare the current item to the rest of the loop.
        for k in range(i+1, len(contacts)):
            # Check if the current item is less than the minimum.
            if contacts[k] < contacts[minimum]:
                minimum = k   # Set the position to minimum if true.
        # Swap the minimum position with the i position.
        contacts[minimum], contacts[i] = contacts[i], contacts[minimum]
    return contacts

def read_contacts(file_path):
    """Returns a list of contacts read from a file."""
    # Opens file on read mode.
    try:
        filelink = open(file_path, "r", encoding='utf-8')
        contacts = []
        for line in filelink:  # Iterate through each line in a file.
            item = line.rstrip().split(",")  # Remove any unneccessary characters.
            contacts.append(item)
        filelink.close()
        return contacts
    except FileNotFoundError:
        print("File not found.")

def search_contact(file_path, query):
    """Prints out the list of contacts found."""
    found_contacts = check_contact(file_path, query)
    returnstring = ''
    if found_contacts:
        returnstring += "Found contact(s):\n"
        returnstring += "=" * 60 + '\n'
        returnstring += f'{"| Name":<23}' + f'{"| Phone":<18}'+ f'{"| Email":<28}'+ "|\n"
        returnstring += "=" * 60
        for contact in found_contacts:
            returnstring += '\n'
            returnstring += f'| {contact[0]:<21}' + f'| {contact[1]:<16}' + f'| {contact[2]:<26}' + "|\n"
            returnstring += "-" * 60
    else:
        returnstring += "No contact found."
    return returnstring

def list_contacts(file_path):
    """Returns a list of all contacts in alphabetical order."""
    contacts = read_contacts(file_path)
    return custom_sort(contacts)

def wildcard(pattern, word):
    """Matches a provided query with a word."""
    # Base case: both strings are empty
    if len(word) == 0 and len(pattern) == 0:
        return True
    # Return False if both strings are empty
    if len(pattern) == 0 or len(word) == 0:
        return False
    # Check if characters match or if pattern has a wildcard
    if pattern[0] == word[0] or pattern[0] == '?' or pattern[0] == '*':
        # If pattern has '*', handle it recursively
        if pattern[0] == '*':
            # Option 1: Ignore '*' and move to the next character in the word
            option1 = wildcard(pattern[1:], word)
            # Option 2: Use '*' to match the current character in the word
            option2 = wildcard(pattern, word[1:])
            # Option 3: Use '*' to match both characters
            option3 = wildcard(pattern[1:], word[1:])
            return option1 or option2 or option3
        else:
            # Recursively check other characters
            return wildcard(pattern[1:], word[1:])
    else:
        # Characters don't wildcard, and no wildcard
        return False
       
def main():
    """Prompts the user for input and outputs the result."""
    file_path = input("Enter the name for the contacts file:\n")
    if not file_path.endswith('.txt'):
        file_path = file_path + '.txt'
    if not path_exists(file_path):
        filelink = open(file_path, "w")
        filelink.close()
        print("Contacts file ", "\'", file_path, "\'", " created.", sep='')
    if path_exists(file_path):  # Check if the file exists.
        print()
        choices = ["1. Add Contact", "2. Search Contact", "3. List Contacts", "4. Exit"]
        for choice in choices:  # Display the options to the user.
            print(choice)
        try:  # Raise an exception if invalid input provided.
            choice = int(input("Enter your choice: "))
        except ValueError:
            print("Enter a valid integer.")
        while choice != 4: 
            if choice == 1:
                print(add_contact(file_path, input("Enter name: ").title(), input("Enter phone number: "), input("Enter email: ")))
            elif choice == 2:
                query = input("Enter first name, last name, phone number, or email to search:\n")
                print(search_contact(file_path, query))
            elif choice == 3:
                print("\nList of contacts:")
                print("=" * 60)
                # Use string formating to output the results in fixed lengths.
                print(f'{"| Name":<23}', f'{"| Phone":<18}', f'{"| Email":<28}', "|", sep='')
                print("=" * 60)
                for contact in list_contacts(file_path):
                    print(f'| {contact[0]:<21}', f'| {contact[1]:<16}', f'| {contact[2]:<26}', "|", sep='')
                    print("-" * 60)
            choices = ["1. Add Contact", "2. Search Contact", "3. List Contacts", "4. Exit"]
            print()
            for choice in choices:
                print(choice)
            choice = int(input("Enter your choice: "))
        if choice == 4:
            print("Exiting program.")
    else:
        print("File not found.")

if __name__ == '__main__':
    main()