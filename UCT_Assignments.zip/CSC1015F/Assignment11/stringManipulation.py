# Counting lowercase characters in a string
# Tracey Letlape
# 26 April 2024

def count_lowercase(s):
    """returns the number of lowercase characters in a given string, s.
    returns the total number of lowercase characters as an integer"""
    count = 0
    for char in s:
        if 97 <= ord(char) <= 122:
            count += 1
    return count


def find_lowercase(s):
    """finds all lowercase characters in a given string, s.
    returns a list of all lowercase characters."""
    lower_case = []
    for char in s:
        if 97 <= ord(char) <= 122:
            lower_case.append(char)
    return lower_case

def main():
    s = input("Enter a string:\n").strip()
    
    # Count lowercase characters
    lowercase_count = count_lowercase(s)
    print(f"The number of lowercase characters in the string is: {lowercase_count}.")
    
    # Find lowercase characters
    lowercase_list = find_lowercase(s)
    
    # Print lowercase characters as a comma-separated list
    print("List of lowercase characters:")
    if len(s) == 0 or lowercase_count == 0:
        print("[]")
    else:
        print(", ".join(lowercase_list))


if __name__ == "__main__":
    main()